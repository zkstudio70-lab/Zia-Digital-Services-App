ZIA DIGITAL SERVICES — APK BUILD

یہ Zia Digital Services کا Android project ہے۔

APK بنانے کے لیے GitHub Actions workflow شامل ہے:
.github/workflows/build-apk.yml

App package: pk.zia.digitalservices
Version: 1.0 (versionCode 1)

اہم: یہ ZIP خود APK نہیں ہے۔ GitHub میں project upload کرنے کے بعد Actions خود APK build کرے گا۔
