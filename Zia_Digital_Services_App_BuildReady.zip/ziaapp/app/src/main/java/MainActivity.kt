package pk.zia.digitalservices

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Service(val title:String,val urdu:String,val icon: androidx.compose.ui.graphics.vector.ImageVector,val desc:String)

val services = listOf(
 Service("NADRA Online Services","نادرا آن لائن سہولیات",Icons.Default.Badge,"نادرا سے متعلق دستیاب آن لائن سہولیات اور درخواست میں رہنمائی۔"),
 Service("Fard / Land Record","زمین کی فرد",Icons.Default.Description,"زمین کی فرد اور متعلقہ آن لائن ریکارڈ سروسز کے لیے رابطہ کریں۔"),
 Service("FBR / Income Tax","ایف بی آر / انکم ٹیکس",Icons.Default.AccountBalance,"ٹیکس ریٹرن اور ایف بی آر سے متعلق آن لائن خدمات۔"),
 Service("BISP Guidance","BISP رہنمائی",Icons.Default.SupportAgent,"BISP سے متعلق معلومات اور آن لائن درخواست میں رہنمائی۔"),
 Service("Online Forms","آن لائن فارم",Icons.Default.EditDocument,"مختلف آن لائن فارم، درخواستیں اور دستاویزات تیار کروائیں۔"),
 Service("Wedding Cards","شادی کارڈ ڈیزائن",Icons.Default.CardGiftcard,"شادی، ولیمہ اور دیگر تقریبات کے خوبصورت کارڈ ڈیزائن۔"),
 Service("Graphic Design","گرافک ڈیزائن",Icons.Default.Brush,"پوسٹر، بینر، لوگو اور سوشل میڈیا ڈیزائن۔"),
 Service("Video Editing","ویڈیو ایڈیٹنگ",Icons.Default.Movie,"Full HD ویڈیو ایڈیٹنگ، مکسنگ اور ایونٹ ویڈیوز۔"),
 Service("Photography","فوٹوگرافی",Icons.Default.PhotoCamera,"تقریبات اور خصوصی مواقع کے لیے فوٹوگرافی۔"),
 Service("DVD / Cassette to USB","DVD / Cassette to USB",Icons.Default.Usb,"پرانے DVD اور Cassette کو USB میں محفوظ کروائیں۔"),
 Service("Printing & Scanning","پرنٹنگ / اسکیننگ",Icons.Default.Print,"پرنٹنگ، اسکیننگ اور ڈیجیٹل ڈاکومنٹ سروسز۔"),
 Service("Other Online Services","دیگر آن لائن سروسز",Icons.Default.MoreHoriz,"دستیاب دیگر ڈیجیٹل اور آن لائن سہولیات کے لیے رابطہ کریں۔")
)

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { ZiaApp() }
 }
}

@Composable fun ZiaApp(){
 var selected by remember { mutableStateOf<Service?>(null) }
 if(selected==null) Home(onService={selected=it}) else ServicePage(selected!!, onBack={selected=null})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Home(onService:(Service)->Unit){
 val context=LocalContext.current
 var showForm by remember { mutableStateOf(false) }
 Scaffold(
  topBar={TopAppBar(title={Text("Zia Digital Services",fontWeight=FontWeight.Bold)})},
  bottomBar={
   NavigationBar{
    NavigationBarItem(selected=true, onClick={}, icon={Icon(Icons.Default.Home,null)}, label={Text("Home")})
    NavigationBarItem(selected=false, onClick={showForm=true}, icon={Icon(Icons.Default.Assignment,null)}, label={Text("Request")})
    NavigationBarItem(selected=false, onClick={ context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:03001595939"))) }, icon={Icon(Icons.Default.Phone,null)}, label={Text("Contact")})
   }
  }
 ){ p->
  LazyColumn(modifier=Modifier.fillMaxSize().padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
   item{
    Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF0B63CE))){
     Column(Modifier.fillMaxWidth().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
      Text("ZIA DIGITAL",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
      Text("ضیاء ڈیجیٹل سروسز",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Color.White)
      Text("ONLINE SERVICES",color=Color.White.copy(alpha=.9f))
      Spacer(Modifier.height(12.dp))
      Text("آپ کی روزمرہ ڈیجیٹل سہولیات، ایک جگہ",color=Color.White,textAlign=TextAlign.Center)
     }
    }
   }
   item{Text("ہماری خدمات",fontSize=22.sp,fontWeight=FontWeight.Bold)}
   items(services.chunked(2)){ row ->
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
     row.forEach{ s->
      Card(Modifier.weight(1f).clickable{onService(s)},shape=RoundedCornerShape(18.dp)){
       Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Icon(s.icon,null,tint=Color(0xFF0B63CE),modifier=Modifier.size(34.dp))
        Spacer(Modifier.height(8.dp))
        Text(s.title,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        Text(s.urdu,fontSize=12.sp,textAlign=TextAlign.Center)
       }
      }
     }
     if(row.size==1) Spacer(Modifier.weight(1f))
    }
   }
   item{
    Card(shape=RoundedCornerShape(18.dp)){
     Column(Modifier.padding(18.dp)){
      Text("📍 ملگدا چوک پاکپتن، اوکاڑہ روڈ",fontWeight=FontWeight.Bold)
      Text("📞 03001595939")
      Spacer(Modifier.height(10.dp))
      Button(onClick={context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/923001595939")))},modifier=Modifier.fillMaxWidth()){
       Icon(Icons.Default.Chat,null); Spacer(Modifier.width(8.dp)); Text("WhatsApp پر رابطہ کریں")
      }
     }
    }
   }
  }
  if(showForm) RequestDialog(onDismiss={showForm=false})
 }
}

@Composable fun ServicePage(s:Service,onBack:()->Unit){
 val context=LocalContext.current
 var form by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().background(Color(0xFFF7FAFF))){
  Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
   IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}
   Text(s.title,fontSize=21.sp,fontWeight=FontWeight.Bold)
  }
  Column(Modifier.padding(20.dp)){
   Icon(s.icon,null,tint=Color(0xFF0B63CE),modifier=Modifier.size(60.dp))
   Spacer(Modifier.height(14.dp))
   Text(s.urdu,fontSize=22.sp,fontWeight=FontWeight.Bold)
   Spacer(Modifier.height(10.dp))
   Text(s.desc,fontSize=17.sp,lineHeight=25.sp)
   Spacer(Modifier.height(25.dp))
   Button(onClick={form=true},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.Assignment,null);Spacer(Modifier.width(8.dp));Text("اس سروس کی درخواست دیں")
   }
   Spacer(Modifier.height(10.dp))
   OutlinedButton(onClick={context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/923001595939?text="+Uri.encode("السلام علیکم، مجھے "+s.title+" کی سروس درکار ہے۔"))))},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.Chat,null);Spacer(Modifier.width(8.dp));Text("WhatsApp پر درخواست دیں")
   }
  }
  if(form) RequestDialog(service=s.title,onDismiss={form=false})
 }
}

@Composable fun RequestDialog(service:String="",onDismiss:()->Unit){
 val context=LocalContext.current
 var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var details by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Online Service Request")},text={
  Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
   Text("سروس: $service")
   OutlinedTextField(name,{name=it},label={Text("نام")},singleLine=true)
   OutlinedTextField(phone,{phone=it},label={Text("موبائل نمبر")},singleLine=true)
   OutlinedTextField(details,{details=it},label={Text("تفصیل")},minLines=3)
  }
 },confirmButton={
  Button(onClick={
   val msg="Zia Digital Services Request\nنام: $name\nموبائل: $phone\nسروس: $service\nتفصیل: $details"
   context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/923001595939?text="+Uri.encode(msg))))
   onDismiss()
  }){Text("WhatsApp پر بھیجیں")}
 },dismissButton={TextButton(onClick=onDismiss){Text("بند کریں")}})
}
